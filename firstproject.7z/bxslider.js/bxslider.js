$('.carusel').bxSlider({
    mode: 'fade',
    controls: false
});